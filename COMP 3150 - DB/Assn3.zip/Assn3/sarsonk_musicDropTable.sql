insert into musician values(111111111, 'Majid Peters', '4747 Oakwood Dr', 1113331112);
delete from contains;
delete from performs;
delete from produces;
delete from play;
delete from musician;
delete from song;
delete from instrument;
delete from album;
COMMIT;

drop table produces;
drop table performs;
drop table contains;
drop table play;
drop table song;
drop table album;
drop table instrument;
drop table musician;
COMMIT;

